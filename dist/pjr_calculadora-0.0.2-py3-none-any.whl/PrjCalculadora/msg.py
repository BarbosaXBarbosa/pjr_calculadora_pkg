#   Mensagens

def cabecalho():
    print('---------------------------------------')
    print('----Bem Vindo à calculadora Python-----')
    print('---------------------------------------')


def menuPrincipal():
    print('1 - Somar'
        '\n2 - Subtrair'
        '\n3 - Multiplicar'
        '\n4 - Dividir'
        '\n5 - Sair do programa')


def Rodape():
    print('---------------------------------------')
