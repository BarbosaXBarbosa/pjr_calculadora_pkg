# pjr_calculadora

Description. 
The package pjr_calculadora is used to:
	- 
	-

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install pjr_calculadora

```bash
pip install pjr_calculadora
```

## Usage

```python
from pjr_calculadora import core
core.calc()
```

## Author
BarbosaXBarbosa

## License
[MIT](https://choosealicense.com/licenses/mit/)